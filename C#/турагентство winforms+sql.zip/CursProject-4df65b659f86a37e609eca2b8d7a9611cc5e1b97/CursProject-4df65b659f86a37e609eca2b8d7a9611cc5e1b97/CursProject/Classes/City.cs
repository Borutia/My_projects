﻿namespace CursProject.Classes
{
    public partial class City
    {
        public override string ToString()
        {
            return Name;
        }
    }
}