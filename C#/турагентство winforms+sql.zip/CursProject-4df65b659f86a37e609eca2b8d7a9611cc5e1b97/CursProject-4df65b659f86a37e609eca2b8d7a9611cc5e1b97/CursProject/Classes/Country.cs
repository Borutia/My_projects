﻿namespace CursProject.Classes
{
    public partial class Country
    {
        public override string ToString()
        {
            return Name;
        }
    }
}