namespace CursProject.Classes
{
    partial class TourDbDataContext
    {
    }
}