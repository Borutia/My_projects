﻿namespace CursProject.Grids
{
    public class GridTripClient
    {
        public int Id { get; set; }
        public string Fio { get; set; }
        public string Name { get; set; }
        public string TotalPrice { get; set; }
        public string LeftPrice { get; set; }
        public string SaleDate { get; set; }
        public bool IsPaid { get; set; }
    }
}