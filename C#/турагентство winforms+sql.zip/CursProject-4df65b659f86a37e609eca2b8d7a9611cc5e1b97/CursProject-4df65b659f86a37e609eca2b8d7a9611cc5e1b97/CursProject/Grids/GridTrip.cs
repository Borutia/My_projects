﻿namespace CursProject.Grids
{
    public class GridTrip
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DateDeparture { get; set; }
        public string DateArival { get; set; }
        public int Nights { get; set; }
        public int Count { get; set; }
        public string TotalPrice { get; set; }
    }
}