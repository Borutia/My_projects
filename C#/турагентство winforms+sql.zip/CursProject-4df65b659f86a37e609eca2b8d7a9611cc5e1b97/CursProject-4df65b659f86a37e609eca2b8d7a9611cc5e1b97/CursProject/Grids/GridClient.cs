﻿namespace CursProject.Grids
{
    public class GridClient
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; }
        public string Fio { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Doc { get; set; }
        public string Discount { get; set; }
        public string TotaPurchases { get; set; }
    }
}