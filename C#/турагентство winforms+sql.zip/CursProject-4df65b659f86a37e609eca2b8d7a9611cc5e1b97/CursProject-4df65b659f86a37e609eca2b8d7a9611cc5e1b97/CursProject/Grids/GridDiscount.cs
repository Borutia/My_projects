﻿namespace CursProject.Grids
{
    public class GridDiscount
    {
        public int Id { get; set; }
        public string Range { get; set; }
        public string Value { get; set; }
    }
}