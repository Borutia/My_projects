﻿namespace CursProject.Types
{
    public enum HotelType
    {
        Stars2,
        Stars3,
        Stars4,
        Stars5
    }
}