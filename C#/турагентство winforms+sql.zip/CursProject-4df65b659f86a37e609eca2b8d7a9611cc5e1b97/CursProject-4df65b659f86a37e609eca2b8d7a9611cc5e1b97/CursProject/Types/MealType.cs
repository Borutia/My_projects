﻿namespace CursProject.Types
{
    public enum MealType
    {
        No,
        BB,
        HB,
        FB
    }
}