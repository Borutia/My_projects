﻿namespace CursProject.Types
{
    public enum TransportType
    {
        Air,
        Train,
        Auto
    }
}