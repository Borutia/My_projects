package com.example.Notes.exception;

public class NotesException extends RuntimeException {
    public NotesException() {
    }

    public NotesException(String message) {
        super(message);
    }

}
