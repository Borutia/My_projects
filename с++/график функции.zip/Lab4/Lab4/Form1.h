#pragma once
#include "parser.h"
#include "Form2.h"
namespace Lab4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
  System::Globalization::NumberFormatInfo ^ nfi;
		Form1(void)
		{
   InitializeComponent();
			nfi = gcnew System::Globalization::NumberFormatInfo();
			nfi->NumberDecimalSeparator = "."; //"��������������" ����� ������������ ����� � ������� �����
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^  panel1;
	protected: 
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  dX;
	private: System::Windows::Forms::TextBox^  x2;
	private: System::Windows::Forms::TextBox^  x1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^  chart1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button2;

	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Legend^  legend1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
			System::Windows::Forms::DataVisualization::Charting::Series^  series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->dX = (gcnew System::Windows::Forms::TextBox());
			this->x2 = (gcnew System::Windows::Forms::TextBox());
			this->x1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->chart1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->chart1))->BeginInit();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Controls->Add(this->dX);
			this->panel1->Controls->Add(this->x2);
			this->panel1->Controls->Add(this->x1);
			this->panel1->Controls->Add(this->textBox1);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Top;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(622, 70);
			this->panel1->TabIndex = 0;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(572, 9);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(37, 32);
			this->button2->TabIndex = 6;
			this->button2->Text = L"tab";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(15, 44);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(594, 17);
			this->label1->TabIndex = 5;
			this->label1->Text = L"������� ������� �� ��������� x, ����� � ������ ������� ���������, ��� �� ��������" 
				L"�";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(534, 9);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(37, 32);
			this->button1->TabIndex = 4;
			this->button1->Text = L"ok";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// dX
			// 
			this->dX->Location = System::Drawing::Point(437, 12);
			this->dX->MaxLength = 10;
			this->dX->Name = L"dX";
			this->dX->Size = System::Drawing::Size(91, 22);
			this->dX->TabIndex = 3;
			this->dX->Text = L"0.01";
			// 
			// x2
			// 
			this->x2->Location = System::Drawing::Point(340, 12);
			this->x2->MaxLength = 10;
			this->x2->Name = L"x2";
			this->x2->Size = System::Drawing::Size(91, 22);
			this->x2->TabIndex = 2;
			this->x2->Text = L"3.14";
			// 
			// x1
			// 
			this->x1->Location = System::Drawing::Point(243, 12);
			this->x1->MaxLength = 10;
			this->x1->Name = L"x1";
			this->x1->Size = System::Drawing::Size(91, 22);
			this->x1->TabIndex = 1;
			this->x1->Text = L"0";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(12, 12);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(225, 22);
			this->textBox1->TabIndex = 0;
			this->textBox1->Text = L"sin(x)";
			// 
			// chart1
			// 
			chartArea1->Name = L"ChartArea1";
			this->chart1->ChartAreas->Add(chartArea1);
			this->chart1->Dock = System::Windows::Forms::DockStyle::Fill;
			legend1->Docking = System::Windows::Forms::DataVisualization::Charting::Docking::Bottom;
			legend1->Name = L"Legend1";
			this->chart1->Legends->Add(legend1);
			this->chart1->Location = System::Drawing::Point(0, 70);
			this->chart1->Name = L"chart1";
			series1->ChartArea = L"ChartArea1";
			series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Line;
			series1->Legend = L"Legend1";
			series1->MarkerStyle = System::Windows::Forms::DataVisualization::Charting::MarkerStyle::Circle;
			series1->Name = L"Series1";
			this->chart1->Series->Add(series1);
			this->chart1->Size = System::Drawing::Size(622, 285);
			this->chart1->TabIndex = 1;
			this->chart1->Text = L"chart1";
			this->chart1->Visible = false;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(622, 355);
			this->Controls->Add(this->chart1);
			this->Controls->Add(this->panel1);
			this->MinimumSize = System::Drawing::Size(640, 400);
			this->Name = L"Form1";
			this->Text = L"Lab_04";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->chart1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion

private: bool Parse (String ^s, double &a) {
 System::IFormatProvider ^ provider = System::Globalization::CultureInfo::GetCultureInfo("en-US");
 bool A = Double::TryParse(s,System::Globalization::NumberStyles::Number, provider,a);
 return A;
}

private: bool Check (String ^Str,double x1) {
 TParser *parser = new TParser();
 try {
  double x=x1;
  Str=Str->Replace("x",x.ToString(nfi));
  char *p = (char*) (Runtime::InteropServices::Marshal::StringToHGlobalAnsi (Str)).ToPointer ();
  parser->Compile(p);
  parser->Evaluate();
  return true;      
 }
 catch (...) {
  return false;
 }
}

private: void Go (String ^S,double x1, double x2, double dX) {
 TParser *parser = new TParser();
 using namespace System::Windows::Forms::DataVisualization::Charting;
 using namespace System::Collections::Generic; 
 using namespace System::Drawing::Drawing2D;
 using namespace System::Drawing;
 using namespace Runtime::InteropServices;
 Dictionary <double, double> f1 = gcnew Dictionary<double, double>();
 String ^ Str;
 double x;
 char *p;
 chart1->Series[0]->ChartType = SeriesChartType::Line;
 chart1->Series[0]->MarkerStyle = MarkerStyle::Circle;
 ArrayList points = gcnew ArrayList();
 
 try {
  for (x=x1; x<=x2; x+=dX) {
   Str=S->Replace("x",x.ToString(nfi));
   p = (char*) (Marshal::StringToHGlobalAnsi(Str)).ToPointer();
   parser->Compile(p);
   parser->Evaluate();
   f1.Add(x, parser->GetResult()); 
  }
 }
 catch(TError error) {
  System::String ^ str1 = gcnew System::String (error.error);
  System::String ^ str2 = gcnew System::String (error.pos.ToString());
  MessageBox::Show ("������ " + str1 +  " � ������� ������ ������� " + str2+" ��� x = "+x,
   "������ �������",MessageBoxButtons::OK);
  //return;
 }
 chart1->Series[0]->LegendText = S;
 chart1->Series[0]->Color = System::Drawing::Color::Green;
 chart1->Series[0]->BorderWidth = 2;
 chart1->Series[0]->Points->DataBindXY(f1.Keys, f1.Values);
}

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
 double x1,x2,dX; String ^ s = textBox1->Text;
 this->chart1->Visible=false;
 if (Parse(this->x1->Text,x1)==false ||
	 Parse(this->x2->Text,x2)==false ||
	 Parse(this->dX->Text,dX)==false) {
  MessageBox::Show ("������� �������� �������� x1,x2,dx","������",MessageBoxButtons::OK);
  return;
 }
 if (x1>x2 || x1+dX>x2) {
  MessageBox::Show ("������� x1<x1+dX<x2","������",MessageBoxButtons::OK);
  return;
 }
 this->chart1->Visible=true;
 if (!Check (s,x1)) {
  MessageBox::Show ("������� ������ �������, �� ���� ����� �������� �� 1-�� ���������",
   "������",MessageBoxButtons::OK);
  return;
 }
 Go (s, x1, x2, dX);
}

private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
 Form2 ^F2 = gcnew Form2;
 using namespace System::Windows::Forms::DataVisualization::Charting;
 for each (DataPoint ^p in chart1->Series[0]->Points) { 
  F2->Do (p->XValue, p->YValues[0],nfi);
 }
 F2->Show();
}


}; /////////////////
}

